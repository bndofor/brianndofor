package blackjack;

import java.util.*;

public class Blackjack implements BlackjackEngine {

	private int account;
	private int bet;
	private Random randomGenerator;
	private int numberOfDecks;

	private ArrayList<Card> deck;

	private ArrayList<Card> hand;
	private ArrayList<Card> dealerHand;

	private int status;

	/**
	 * Constructor you must provide. Initializes the player's account to 200 and the
	 * initial bet to 5. Feel free to initialize any other fields. Keep in mind that
	 * the constructor does not define the deck(s) of cards.
	 * 
	 * @param randomGenerator
	 * @param numberOfDecks
	 */
	public Blackjack(Random randomGenerator, int numberOfDecks) {
		this.account = 200;
		this.bet = 5;
		this.randomGenerator = randomGenerator;
		this.numberOfDecks = numberOfDecks;

	}

	public int getNumberOfDecks() {
		return this.numberOfDecks;
	}

	public void createAndShuffleGameDeck() {
		deck = new ArrayList<Card>();

		for (int i = 0; i < this.numberOfDecks; i++) {
			for (CardSuit s : CardSuit.values()) {
				for (CardValue v : CardValue.values()) {
					this.deck.add(new Card(v, s));
				}
			}
		}

		Collections.shuffle(deck, randomGenerator);
	}

	public Card[] getGameDeck() {
		Card[] gameDeck = new Card[deck.size()];
		return deck.toArray(gameDeck);
	}

	public void deal() {
		createAndShuffleGameDeck();

		this.dealerHand = new ArrayList<Card>();
		this.hand = new ArrayList<Card>();

		hand.add(deck.remove(0));
		Card card = deck.remove(0);
		card.setFaceDown();
		dealerHand.add(card);

		hand.add(deck.remove(0));
		dealerHand.add(deck.remove(0));

		status = BlackjackEngine.GAME_IN_PROGRESS;
		setAccountAmount(this.account -= this.bet);
		//

	}

	public Card[] getDealerCards() {
		Card[] card = new Card[dealerHand.size()];
		return dealerHand.toArray(card);
	}

	public int[] getDealerCardsTotal() {
		return handTotal(this.dealerHand);
	}

	public int getDealerCardsEvaluation() {
		return evaluate(getDealerCardsTotal(), this.dealerHand);
	}

	public Card[] getPlayerCards() {
		Card[] card = new Card[hand.size()];
		return hand.toArray(card);
	}

	public int[] getPlayerCardsTotal() {
		return handTotal(this.hand);
	}

	public int getPlayerCardsEvaluation() {
		return evaluate(getPlayerCardsTotal(), this.hand);
	}

	public void playerHit() {
		hand.add(deck.remove(0));

		if (getPlayerCardsEvaluation() != Blackjack.BUST) {
			status = BlackjackEngine.GAME_IN_PROGRESS;
		} else {
			status = BlackjackEngine.DEALER_WON;
		}
	}

	public void playerStand() {
		dealerHand.get(0).setFaceUp();
		boolean isValid = false;

		int[] dealerHandTotal;
		int[] playerHandTotal;

		dealerHandTotal = getDealerCardsTotal();
		playerHandTotal = getPlayerCardsTotal();

		if (getPlayerCardsEvaluation() == BLACKJACK) {
			status = PLAYER_WON;
			
			account += (bet * 2);
			return;

		}

		if (getDealerCardsEvaluation() == BLACKJACK) {
			status = DEALER_WON;
			account += (bet * 2);

			return;

		}

		while (true) {
			if (dealerHandTotal == null || dealerHandTotal[dealerHandTotal.length - 1] >= 16) {
				break;
			} else {
				dealerHand.add(deck.remove(0));
				dealerHandTotal = getDealerCardsTotal();
			}

		}

		if (playerHandTotal == null) {
			status = BlackjackEngine.DEALER_WON;
		} else if (dealerHandTotal == null) {
			status = BlackjackEngine.PLAYER_WON;
			account += (bet * 2);
		} else if (dealerHandTotal[dealerHandTotal.length - 1] > playerHandTotal[playerHandTotal.length - 1]) {
			status = BlackjackEngine.DEALER_WON;
		} else if (dealerHandTotal[dealerHandTotal.length - 1] < playerHandTotal[playerHandTotal.length - 1]) {
			status = BlackjackEngine.PLAYER_WON;
			account += (bet * 2);
		} else {
			status = BlackjackEngine.DRAW;
			account += (bet);
		}

//		if (playerHandTotal == null) {
//			status = BlackjackEngine.DEALER_WON;
//		} else if (dealerHandTotal == null) {
//			status = BlackjackEngine.PLAYER_WON;
//			account += (bet * 2);
//		} else if (dealerHandTotal.length == 2 && playerHandTotal.length == 2) {
//			if (dealerHandTotal[1] < playerHandTotal[1]) {
//				status = BlackjackEngine.PLAYER_WON;
//				account += (bet * 2);
//			} else if (dealerHandTotal[1] > playerHandTotal[1]) {
//				status = BlackjackEngine.DEALER_WON;
//			} else {
//				status = BlackjackEngine.DRAW;
//				account += (bet);
//			}
//		} else if (dealerHandTotal.length == 2 && playerHandTotal.length == 1) {
//			if (dealerHandTotal[1] < playerHandTotal[0]) {
//				status = BlackjackEngine.PLAYER_WON;
//				account += (bet * 2);
//			} else if (dealerHandTotal[1] > playerHandTotal[0]) {
//				status = BlackjackEngine.DEALER_WON;
//			} else {
//				status = BlackjackEngine.DRAW;
//				account += (bet);
//			}
//		} else if (dealerHandTotal.length == 1 && playerHandTotal.length == 1) {
//			if (dealerHandTotal[0] < playerHandTotal[0]) {
//				status = BlackjackEngine.PLAYER_WON;
//				account += (bet * 2);
//			} else if (dealerHandTotal[0] > playerHandTotal[0]) {
//				status = BlackjackEngine.DEALER_WON;
//			} else {
//				status = BlackjackEngine.DRAW;
//				account += (bet);
//			}
//		} else if (dealerHandTotal.length == 1 && playerHandTotal.length == 2) {
//			if (dealerHandTotal[0] < playerHandTotal[1]) {
//				status = BlackjackEngine.PLAYER_WON;
//				account += (bet * 2);
//			} else if (dealerHandTotal[0] > playerHandTotal[1]) {
//				status = BlackjackEngine.DEALER_WON;
//			} else {
//				status = BlackjackEngine.DRAW;
//				account += (bet);
//			}
//		}

	}

	public int getGameStatus() {
		return this.status;
	}

	public void setBetAmount(int amount) {
		this.bet = amount;
	}

	public int getBetAmount() {
		return this.bet;
	}

	public void setAccountAmount(int amount) {
		this.account = amount;
	}

	public int getAccountAmount() {
		return this.account;
	}

	/* Feel Free to add any private methods you might need */

	private int[] handTotal(ArrayList<Card> hand) {
		boolean hasAce = false;
		int total = 0;
		int totalWithAce = 0;
		int totalWithEleven = 0;

		for (int i = 0; i < hand.size(); i++) {
			if (hand.get(i).getValue() == CardValue.Ace) {
				hasAce = true;
			}
		}

		if (hasAce == false) {
			for (Card c : hand) {
				total += c.getValue().getIntValue();
			}
			if (total > 21) {
				return null;
			}
			int[] array = { total };
			return array;
		} else {
			for (Card c : hand) {
				totalWithAce += c.getValue().getIntValue();
			}
			totalWithEleven = totalWithAce + 10;

			if (totalWithAce > 21) {
				return null;
			} else if (totalWithAce <= 21 && totalWithEleven > 21) {
				int[] array = { totalWithAce };
				return array;
			} else {
				int[] array = { totalWithAce, totalWithEleven };
				return array;
			}

		}
	}

	private int evaluate(int[] handTotal, ArrayList<Card> hand) {
		if (handTotal == null) {
			return BlackjackEngine.BUST;
		}
		if (handTotal.length == 2) {
			if (handTotal[1] == 21) {
				if (hand.size() <= 2) {
					return BlackjackEngine.BLACKJACK;
				} else {
					return BlackjackEngine.HAS_21;
				}
			}
		} else {
			if (handTotal[0] == 21) {
				if (hand.size() >= 2) {
					return BlackjackEngine.HAS_21;
				} else {
					return BlackjackEngine.BLACKJACK;
				}
			}
		}
		return BlackjackEngine.LESS_THAN_21;

	}
}